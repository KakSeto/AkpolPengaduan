<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.2.18
    </div>
    <strong>Copyright &copy; 2019 <a href="#">AKPOL</a>.</strong> All rights
    reserved.
  </footer>
