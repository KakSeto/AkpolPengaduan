<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> MASIH BETA :D
    </div>
    <strong>Copyright &copy; 2019 <a href="#">AKPOL</a>.</strong> All rights
    reserved.
  </footer>
